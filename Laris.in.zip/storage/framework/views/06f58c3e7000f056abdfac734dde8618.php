<?php $__env->startSection('titlepage','Produk / Barang'); ?>
<?php $__env->startSection('page_actionbutton'); ?>

<a class="btn btn-primary btn-border btn-round" href="<?php echo e(route('add_product')); ?>">
    <svg  xmlns="http://www.w3.org/2000/svg"  width="24"  height="24"  viewBox="0 0 24 24"  fill="none"  stroke="currentColor"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-book-upload"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 20h-8a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h12v5" /><path d="M11 16h-5a2 2 0 0 0 -2 2" /><path d="M15 16l3 -3l3 3" /><path d="M18 13v9" /></svg>
    <?php echo e(__('Tambah Produk / Barang')); ?>

</a>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(Session::has('error')): ?>
		<div class="alert alert-important alert-danger alert-dismissible" role="alert">
			<div class="d-flex">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon alert-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/alert-circle</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="12" cy="12" r="9"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
				<div>
					<?php echo e(__(Session::get('error'))); ?>

				</div>
			</div>
			<a class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="close"></a>
		</div>
	<?php endif; ?>
	<?php if(Session::has('success')): ?>
		<div class="alert alert-important alert-success alert-dismissible" role="alert">
			<div class="d-flex">
				<svg xmlns="http://www.w3.org/2000/svg" class="icon alert-icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><desc>Download more icon variants from https://tabler-icons.io/i/check</desc><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
				<div>
					<?php echo e(__(Session::get('success'))); ?>

				</div>
			</div>
			<a class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="close"></a>
		</div>
	<?php endif; ?>
	<div id="message-alert"></div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header"><h4><?php echo e(__('Daftar Produk / Barang')); ?></h4></div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center"><?php echo e(__('No. ')); ?></th>
                                    <th class="text-center"><?php echo e(__('Kode ')); ?></th>
                                    <th class="text-center"><?php echo e(__('Nama')); ?></th>
                                    <th class="text-center"><?php echo e(__('Harga Jual')); ?></th>
                                    <th class="text-center"><?php echo e(__('Status')); ?></th>
                                    <th class="w-1 text-center"><?php echo e(__(' Aksi ')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                ?>
                                <?php if(isset($data['main']) && count($data['main']) > 0): ?>
                                    <?php $__currentLoopData = $data['main']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($no++); ?></td>
                                            <td class="text-center"><b><?php echo e($value->product_code); ?></b></td>
                                            <td><?php echo e($value->product_name); ?></td>
                                            <td class="text-end"><?php echo e(formatRupiah($value->product_sale_price)); ?></td>
                                            <td class="text-center">
                                                <?php if($value->product_stats != "ACTIVE"): ?>
                                                <span class="badge badge-danger"><?php echo e($value->product_stats); ?></span>
                                                <?php else: ?>
                                                <span class="badge badge-success"><?php echo e($value->product_stats); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center w-1">
                                                <div class="btn-group dropdown">
                                                    <button class="btn btn-primary dropdown-toggle btn-sm" type="button" data-bs-toggle="dropdown"
                                                    >
                                                      <i class="fas fa-pencil-alt"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" role="menu">
                                                      <li>
                                                        <a class="dropdown-item" href="#">Comming Soon ...</a>
                                                        <a class="dropdown-item" href="#">Comming Soon ...</a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item" href="#">Comming Soon ...</a
                                                        >
                                                      </li>
                                                    </ul>
                                                  </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if(isset($data['main']) && count($data['main']) > 0): ?>
                <div class="card-footer d-flex align-items-center">
                    <?php echo e($data['main']->links('vendor.pagination.bootstrap-5', ['tablename' => $data['tables'][0]])); ?>

                </div>
                <?php endif; ?>	
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\LENOVO\Documents\GitHub\Laris.in\resources\views/product/index.blade.php ENDPATH**/ ?>
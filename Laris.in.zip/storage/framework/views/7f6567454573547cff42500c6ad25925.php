<?php $__env->startSection('titlepage','Tambah Produk / Barang'); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <form action="<?php echo e(route('store_product')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">
                        <h4 class="header-title"><?php echo e(__('Form Tambah Produk / Barang')); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="productcompany" class="form-label"><?php echo e(__('Pilih Asal Produk')); ?></label>
                                    <select name="productcompany" id="productcompany" class="form-control" required>
                                        <option value="" disabled> <?php echo e(__('Pilih Asal Produk / Barang')); ?></option>
                                        <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->company_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="productname" class="form-label"><?php echo e(__('Masukkan Nama Produk/Barang')); ?></label>
                                <input type="text" class="form-control" name="productname" id="productname" placeholder="Masukkan Nama Produk/Barang" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4 col-md-6 col-lg-6">
                                <div class="mb-3">
                                    <label for="productvol" class="form-label"><?php echo e(__('Satuan Produk / Barang')); ?></label>
                                    <select name="productvol" id="productvol" class="form-control" required>
                                        <option value=""><?php echo e(__('Pilih Satuan Produk / Barang')); ?></option>
                                        <option value="PCS"><?php echo e(__('Pcs')); ?></option>
                                        <option value="KG"><?php echo e(__('Kilogram')); ?></option>
                                        <option value="PACKAGE"><?php echo e(__('Paket')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-6 col-lg-6">
                                <div class="mb-3">
                                    <label for="buyPrice" class="form-label"><?php echo e(__('Harga Awal / Beli Produk / Barang')); ?></label>
                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-text">Rp. </span>
                                            <input type="text" class="form-control text-end numeric-input" name="buyPrice" id="buyPrice" required>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['buyPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><i id="error-text"></i></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-sm-4 col-md-6 col-lg-6">
                                <div class="mb-3">
                                    <label for="salePrice" class="form-label"><?php echo e(__('Harga Jual Produk / Barang')); ?></label>
                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-text">Rp. </span>
                                            <input type="text" class="form-control text-end numeric-input" name="salePrice" id="salePrice" required>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['salePrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><i id="error-text"></i></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a class="btn btn-danger btn-rounded" href="<?php echo e(route('product')); ?>">
                            <i class="fas fa-ban"></i>
                            <?php echo e(__('Keluar')); ?>

                        </a>
                        <button type="submit" class="btn btn-primary btn-rounded" style="float: right">
                            <i class="fas fa-save"></i>
                            <?php echo e(__('Simpan')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php $__env->startSection('additional_js'); ?>
	<script src="<?php echo e(asset('larisin/js/larisin/product.js')); ?>"></script>
	<?php $__env->stopSection(); ?>  
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\LENOVO\Documents\GitHub\Laris.in\resources\views/product/form-create.blade.php ENDPATH**/ ?>